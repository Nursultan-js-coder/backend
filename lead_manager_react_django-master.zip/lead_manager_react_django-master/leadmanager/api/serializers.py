from rest_framework import serializers
from .models import Room


class RoomSerializer(serializers.ModelSerializer):
    class Meta:
        model = Room
        fields = ('id', 'code', 'created_at', 'code',
                  'host', 'quest_can_pause', 'votes_to_skip'
                  )


