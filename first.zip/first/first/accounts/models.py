from django.db import models
from django.conf  import settings

# Create your models here.

class Person(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    img=models.ImageField( upload_to="users", height_field=None, width_field=None, max_length=None)
    def __str__(self):
        return self.user.username


