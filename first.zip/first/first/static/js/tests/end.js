//elements
const btn=document.querySelector('#save')

let mostResentScore=localStorage.getItem("mostResentScore");
mostResentScore=JSON.parse(mostResentScore)
btn.addEventListener("click",()=>{
window.location.assign('/testing/storeScore/'+mostResentScore.toString());

})
// const usernameInput=document.querySelector('#usernameInput');

// //data from user (score)

// let mostResentScore=localStorage.getItem("mostResentScore");
// mostResentScore=JSON.parse(mostResentScore)
// let highscoreList=JSON.parse(localStorage.getItem("highscoreList"))||[]

//  usernameInput.addEventListener("keyup",(e)=>{
//      if (e.target.value=='')
//      {
//          btn.style.disabled=true;
//      }
//      else{
//          btn.style.disabled=false;
//      }
//  })


// btn.addEventListener("click",(e)=>
// {
//   e.preventDefault();
//   if(usernameInput.value!="")
//   {
//     let user={
//         "username":usernameInput.value,
//         "score":mostResentScore
//     }
//     highscoreList.push(user);
// highscoreList.sort((a,b)=>{
//      return b.score-a.score}
//      );
//      highscoreList.splice(5);
//   localStorage.setItem("highscoreList",JSON.stringify(highscoreList))
//      window.location.assign('/testing/storeScore/'+mostResentScore.toString());
// }  
  


// })






