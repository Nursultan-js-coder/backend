const highscoreTable=document.querySelector("#highscoreList")
let highscoreList=JSON.parse(localStorage.getItem("highscoreList"))||[]

highscoreList.forEach((highscore)=>{
let td=document.createElement("td")
let td2=document.createElement("td")
let tr=document.createElement("tr");
let scoreP=document.createTextNode(highscore.score);
let usernameP=document.createTextNode(highscore.username);
td.appendChild(usernameP)
td2.appendChild(scoreP)
tr.appendChild(td)
tr.appendChild(td2)
highscoreTable.appendChild(tr);



})