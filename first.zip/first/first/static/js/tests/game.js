let progressText=document.getElementById('progressText');
let progressBarFull=document.getElementById('progressBarFull');
let scoreText=document.querySelector('#score span');
let question_content=document.querySelector('#question_content');
console.log(question_content)



let choices=document.querySelectorAll(".choices .single_choice .choice")

let questions=[];
let availableQuestions=[];
let currentQuestion;
let score;


const POINTFORCORRECTANSWER=10;
const MAXQUESTION=3;
let count=1;

fetch(
    'https://opentdb.com/api.php?amount=10&category=10&type=multiple'
).then((response)=>{
  return response.json()  
}).then((data)=>{
   
    questions=data.results.map((questionObj)=>{
        let formatedQuestion={
            "question":questionObj.question
        }
        let answerChoices=[...questionObj['incorrect_answers']]
        formatedQuestion.answer=Math.floor(Math.random()*4)
        answerChoices.splice(formatedQuestion.answer,0,questionObj['correct_answer']);
       answerChoices.forEach((choice,index)=>{
           formatedQuestion['choice'+(index+1)]=choice;
       })
        return formatedQuestion;

    })

startGame()
}).catch((err) => {
        console.error(err);
    });

 
 function startGame()
 {
score=0;
count=0;
scoreText.innerText=score;
availableQuestions=[...questions]
getNewQuestion();

 }

 function  getNewQuestion(){
choices.forEach(choice=>{
   if(choice.classList.contains("correct"))
   {
       choice.classList.remove("correct");
   }
   if(choice.classList.contains("incorrect"))
   {
       choice.classList.remove("incorrect");
   }
})
if( count< 3 || availableQuestions.length === 0 ){
let index=Math.floor(Math.random()*(availableQuestions.length));    
currentQuestion=availableQuestions[index];
progressBarFull.style.width=`${(count/MAXQUESTION)*100+'%'}`;

availableQuestions.splice(index,1);
question_content.innerText=currentQuestion.question;
choices.forEach((choice,index)=>{
    choice.innerText=currentQuestion['choice'+(index+1)];
  
}) 
console.log(currentQuestion.answer)
count++;

}
else{
    endGame();
    localStorage.setItem("mostResentScore",score);
}
 }

 choices.forEach(choice=>{
   
     choice.addEventListener("click",(e)=>{
     let answerGiven=e.target.dataset.choice;
     if(answerGiven == currentQuestion.answer){
         score+=POINTFORCORRECTANSWER;


     }
   let classToAdd = (answerGiven==currentQuestion.answer)? "correct":"incorrect";
e.target.classList.add(classToAdd);
scoreText.innerText=score;
setTimeout((elem=e.target,classToAdd)=>{
elem.classList.remove(classToAdd);
getNewQuestion()
},1000);
progressText.innerHTML=`question ${count}/${MAXQUESTION}`;






     })
 })

 function endGame()
 {
    return window.location.assign('test_end');
 }

 function addClass(element,className)
 {
element.classList.add(className);
 }
 


