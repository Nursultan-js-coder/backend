const sidebar_list=document.querySelectorAll(".sidebar-menu-list-item");
const reply_button=document.querySelectorAll(".comment-reply-button");
const btn=document.querySelector('.student-search-button');
const list2=document.querySelectorAll(".student-table tbody tr .student-name");

answer_buttons=document.querySelectorAll('.answer-button');

let i=0;





sidebar_list.forEach(element=>{
    element.addEventListener("click",(e)=>{
        if(e.target.dataset.flag==0||e.target.dataset.flag==null){
       for(let i=0;i<4;i++){ 
        const li2=document.createElement("li");
        li2.classList.add("sidebar-menu-list-item");
        li2.classList.add("added");
        li2.style.height="40px";
        li2.style.width="90%";
        const p=document.createElement("p");
        p.innerText="this is appended"
        li2.appendChild(p);
    
        e.target.dataset.flag=1;
        element.parentNode.insertBefore(li2, element.nextSibling);
       }
       element.classList.add('underline');
        }
        else if(e.target.dataset.flag==1){
            for(let i=0;i<4;i++){ 
            const toRem=document.querySelector(".added");
            element.parentNode.removeChild(toRem);
            e.target.dataset.flag=0;
            }
            element.classList.remove('underline');
        }
    })
})

reply_button.forEach(button=>{
    
    button.addEventListener("click",(e)=>{
    if(e.target.dataset.flag==0||e.target.dataset.flag==null){
    const ul=document.createElement("ul");
    for(let i=0;i<4;i++)
    {
        const li=document.createElement("li");
        const p=document.createElement("p");
        let str="really cool";
        p.appendChild(document.createTextNode(str));
        li.appendChild(p);
        ul.appendChild(li);

        
    }
    e.target.parentNode.appendChild(ul);
    e.target.dataset.flag=1;
}
else if(e.target.dataset.flag==1)
{
    const ul=e.target.parentNode.querySelector("ul");
    ul.remove();
    e.target.dataset.flag=0;

}
})
})

answer_buttons.forEach(button=>{
    button.addEventListener("click",(e)=>{
        if(e.target.dataset.flag==0||e.target.dataset.flag==null){
            
        const div=document.createElement("div");
        div.classList.add('container-flex');
        div.classList.add('justify-content-between');
        div.classList.add('justify-content-center');
        // div.classList.add('marginify');
        // div.classList.add('paddingify');
        div.classList.add('width-100-percent');
        const input=document.createElement("input");
      input.classList.add("reply-input")
        const button2=document.createElement("button");
        
        button2.innerHTML="send"
        button2.classList.add("reply-button");
        div.appendChild(input);
        div.appendChild(button2);
        e.target.dataset.flag=1;
        e.target.parentNode.insertBefore(div, e.target.nextSibling);
    }
    else if(e.target.dataset.flag==1)
    {
        const div=e.target.parentNode.querySelector("div");
        div.remove();
        e.target.dataset.flag=0;
    
    }
    })
})
function synchronize(){
const list=document.querySelectorAll(".search-result li");
list.forEach(search_list_item=>{
  search_list_item.addEventListener('click',(e)=>{
        console.log("search itme is clicked");
        list2.forEach(list2_item=>{
            let expression=search_list_item.innerText.split("|")[0].trim().toLowerCase();
            let pattr1=new RegExp(expression,'i');

         if(list2_item.innerText.trim().toLowerCase().search(pattr1)!=-1){ 
console.log('found');
list2_item.parentElement.classList.add("target");
console.log(list2_item.parentElement);
temp_fun(list2_item.parentElement);
         }
         
            })
            
    

    })
})
}




function temp_fun(target){



target.scrollIntoView();
let timeout=1000;
target.classList.add('active');

let myTimeOut=setTimeout(function(){
    target.classList.remove('active');
    target.classList.remove('target');
},timeout);

myTimeOut;
document.querySelector(".student-search-input").value=target.querySelector('.student-name').innerText;

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////