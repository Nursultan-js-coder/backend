const sidebar_list=document.querySelectorAll(".sidebar-menu-list-item");
const reply_button=document.querySelectorAll(".reply-button");
const btn=document.querySelector('.student-search-button');
const list2=document.querySelectorAll(".student-table tbody tr .student-name");
const btn2 = document.querySelector('.btn2')
const input2 = document.querySelector('#id_content')
const answer_btns = document.querySelectorAll('.comment-answer-button');

let reply_buttons=document.querySelectorAll('.comment-reply-button');

let i=0;





sidebar_list.forEach(element=>{
    element.addEventListener("click",(e)=>{
        if(e.target.dataset.flag==0||e.target.dataset.flag==null){
       for(let i=0;i<4;i++){ 
        const li2=document.createElement("li");
        li2.classList.add("sidebar-menu-list-item");
        li2.classList.add("added");
        li2.style.height="40px";
        li2.style.width="90%";
        const p=document.createElement("p");
        p.innerText="this is appended"
        li2.appendChild(p);
    
        e.target.dataset.flag=1;
        element.parentNode.insertBefore(li2, element.nextSibling);
       }
       element.classList.add('underline');
        }
        else if(e.target.dataset.flag==1){
            for(let i=0;i<4;i++){ 
            const toRem=document.querySelector(".added");
            element.parentNode.removeChild(toRem);
            e.target.dataset.flag=0;
            }
            element.classList.remove('underline');
        }
    })
})


// const comment_reply_buttons=document.querySelectorAll(".comment-reply-button");
// comment_reply_buttons.forEach(btn=>{
// btn.addEventListener("click",(e)=>{
//     let responds_div=e.target.nextSibling.querySelector(".responds");
//      if(responds_div.classList.contains('hidden')==true)
//      {
//          responds_div.classList.remove("hidden");
//      }
//      else{
//         responds_div.classList.add("hidden");

//      }
// })
// })
reply_buttons.forEach(button=>{
    button.addEventListener("click",(e)=>{
        if(e.target.parentElement.querySelector(".respondForm").classList.contains('hidden')==true){
     let respondForm=e.target.parentElement.querySelector(".respondForm");
     respondForm.querySelector("textarea").classList.add('reply-input');
    
     respondForm.classList.remove("hidden");
     respondForm.classList.add("width-100-percent");
    
        }
        else{
            let respondForm=e.target.parentElement.querySelector(".respondForm");
            respondForm.classList.add("hidden");
        }
    })
})
function synchronize(){
const list=document.querySelectorAll(".search-result li");
list.forEach(search_list_item=>{
  search_list_item.addEventListener('click',(e)=>{
        console.log("search itme is clicked");
        list2.forEach(list2_item=>{
            let expression=search_list_item.innerText.split("|")[0].trim().toLowerCase();
            let pattr1=new RegExp(expression,'i');

         if(list2_item.innerText.trim().toLowerCase().search(pattr1)!=-1){ 
console.log('found');
list2_item.parentElement.classList.add("target");
console.log(list2_item.parentElement);
temp_fun(list2_item.parentElement);
         }
         
            })
            
    

    })
})
}




function temp_fun(target){



target.scrollIntoView();
let timeout=1000;
target.classList.add('active');

let myTimeOut=setTimeout(function(){
    target.classList.remove('active');
    target.classList.remove('target');
},timeout);

myTimeOut;
document.querySelector(".student-search-input").value=target.querySelector('.student-name').innerText;

}

const comment_button=document.querySelector("#commentForm textarea ");
comment_button.classList.add("reply-input");

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
document.querySelectorAll('.btn2').forEach(btn => {

    btn.addEventListener('click', (e) => {
        e.preventDefault();
      
        let value=e.target.parentElement.querySelector('#id_content').value
        console.log('value:',"he")
        const data = {
            author: "1",
            article: "1",
            content: value,
            date:"2020-12-11"
          };
        fetch("http://localhost:8000/comments/", {
            method: "POST",
            credentials: "include",
            headers: {
              "X-CSRFToken": getCookie("csrftoken"),
              Accept: "application/json",
              "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
          })
            .then(function (response) {
              return response.json();
            })
            .then(function (data) {
              console.log("Data is ok: ", data);
            })
            .catch(function (ex) {
              console.log("parsing failed", ex);
            });
    })
})



  function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(";");
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == " ") {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }

reply_button.forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        const comment_id = e.target.parentElement.querySelector('#comment_id').value;
        console.log("comment_id", comment_id);
        const value = e.target.parentElement.querySelector('#id_content').value;
        const data = {
            "id": 1,
            "content": value,
            "date": "2020-12-11T05:30:10Z",
            "comment": comment_id,
            "author": 1
        };
    
        fetch("http://localhost:8000/responds/", {
            method: "POST",
            credentials: "include",
            headers: {
                "X-CSRFToken": getCookie("csrftoken"),
                Accept: "application/json",
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                console.log("Data is ok: ", data);
            })
            .catch(function (ex) {
                console.log("parsing failed", ex);
            });
    });
});


answer_btns.forEach(btn => {
    btn.addEventListener('click', (e) => {
        fetch('http://localhost:8000/responds')
            .then(res => {
                return res.json();
            })
            .then(data => {
                if (e.target.classList.contains('hidden')) {
                    let respondsUL = e.target.parentElement.nextElementSibling();
                    
                    console.log(respondsUL);
                    let comment_id = e.target.parentElement.querySelector('#comment_id').value
                    let responds2 = data.filter(resp => {
                        if (comment_id == resp.comment) {
                            let li = document.createElement('li');
                            li.innerHTML = `<p>${resp.content}</p>`;
                            respondsUL.appendChild(li);
                            return resp;
                        }
                    })
                }
                else if (!e.target.classList.contains('hidden')) {
                    
                }
                

  

            })
         
    })
    
})