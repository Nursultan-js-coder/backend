const hourP = document.getElementById("hour")
const secondP = document.getElementById("second")
const minuteP = document.getElementById("minute")
//one minute 1000*60 
//one hour 1000*60*60 
//one day 1000*60*60*24 
const img = $("#ay");

const aksam = $('#aksam');
// const img= AyinSekliURL: "https://namazvakti.diyanet.gov.tr/images/i6.gif"
const gunes = $('#gunes');
const hicri = $('#hicriTarihKisa');
const ikindi = $('#ikindi');
const imsak = $('#imsak');
const miladi = $('#miladiTarihKisa');
const ogle = $('#ogle');
const yatsi = $('#yatsi');
console.log(aksam);
console.log(gunes);
console.log(ikindi);
console.log(imsak);
console.log(miladi);
console.log(ogle);
console.log(yatsi);
let data2 = []
let valueOfIkindi;
let valueOfImsak;
let valueOfYatsi;
let valueOfOgle;
let valueOfAksam;

fetch('https://ezanvakti.herokuapp.com/vakitler/15071')
    .then((response) => {
        return response.json();
    }).then((data) => {
        console.log(data);

        let today = new Date().getDate();
        let month = new Date().getMonth();
        let year = new Date().getFullYear();



        img.attr('src', data[today]['AyinSekliURL'])
        img.attr("width", "30px");
        img.attr("height", "30px");
        aksam.text(data[today]['Aksam'])

        gunes.text(data[today]['Gunes']);
        hicri.text(data[today]['HicriTarihKisa']);
        ikindi.text(data[today]['Ikindi']);
        imsak.text(data[today]['Imsak']);
        miladi.text(data[today]['MiladiTarihKisa']);
        ogle.text(data[today]['Ogle']);
        yatsi.text(data[today]['Yatsi']);
        data2 = data;



        let temp = data[today]['Aksam'].split(":");
        let hour = parseInt(temp[0]);
        let minute = parseInt(temp[1]);
        valueOfAksam = new Date(year, month, today, hour, minute);
        temp = data[today]['Ikindi'].split(":");
        hour = parseInt(temp[0]);
        minute = parseInt(temp[1]);

        valueOfIkindi = new Date(year, month, today, hour, minute);
        temp = data[today]['Imsak'].split(":");
        hour = parseInt(temp[0]);
        minute = parseInt(temp[1]);

        valueOfImsak = new Date(year, month, today, hour, minute);
        temp = data[today]['Ogle'].split(":");
        hour = parseInt(temp[0]);
        minute = parseInt(temp[1]);

        valueOfOgle = new Date(year, month, today, hour, minute);
        temp = data[today]['Yatsi'].split(":");
        hour = parseInt(temp[0]);
        minute = parseInt(temp[1]);

        valueOfYatsi = new Date(year, month, today, hour, minute);

        console.log(` aksam namazi: ${valueOfYatsi}`);





    })


function updateTime() {
    var myInterval = setInterval(() => {
        let date = new Date()
        let hour = date.getHours()
        let month = date.getMonth()
        let minute = date.getMinutes()
        let second = date.getSeconds()
        let today = date.getDate();
        let year = date.getFullYear();

        //let rightNow=new Date(year,month,today,hour,minute);
        let rightNow = new Date(year, month, today, hour, minute);

        let value = rightNow.valueOf();
        valueOfYatsi = valueOfYatsi.valueOf();
        valueOfAksam = valueOfAksam.valueOf();
        valueOfIkindi = valueOfIkindi.valueOf();
        valueOfOgle = valueOfOgle.valueOf();

        console.log(` now: ${rightNow}`)




        if (value < valueOfImsak) {
            rightNow = new Date(year, month, today + 1, 4, 34);

            value = rightNow.valueOf();

        }



        // valueOfYatsi=valueOfYatsi.valueOf();



        let arr2 = [imsak, ogle, ikindi, aksam, yatsi];
        let arr = [valueOfImsak, valueOfOgle, valueOfIkindi, valueOfAksam, valueOfYatsi];

        for (let i = arr.length - 1; i >= 0; i--) {
            if (value - arr[i] > 0) {

                let para = arr2[i].parent();
                para.children().addClass("active");


                for (let j = 0; j < arr.length; j++) {
                    if (i != j) {
                        para = arr2[j].parent();
                        para.children().removeClass("active");
                    }
                }
                break;
            }
        }


        if (hour < 10) {
            hour = `0${hour}`
        }

        if (second < 10) {
            second = `0${second}`

        }

        if (minute < 10) {
            minute = `0${minute}`
        }

        hourP.innerText = hour;
        minuteP.innerText = minute;
        secondP.innerText = second;

    }, 1000);
    myInterval


}
updateTime()



City_API_endpoint = "http://api.openweathermap.org/data/2.5/weather?q="
City = "Nairobi"
Country = ",KE,"
join_key = "&appid=" + "b6907d289e10d714a6e88b30761fae22"
units = "&units=metric"

current_city_weather = City_API_endpoint + City + Country + join_key + units
console.log(current_city_weather)

fetch(`http://api.openweathermap.org/data/2.5/weather?q=Nairobi,KE,&appid=b6907d289e10d714a6e88b30761fae22&units=metric`)
    .then((response) => {
        if (response.status == 401) {
            console.log("you,guys not auhenticated")
        }
        return response.json();
    }).then((data) => {
        console.log(data);
    }).catch((error) => {
        console.log(error)
    })


