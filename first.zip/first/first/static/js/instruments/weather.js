const apiKey = "4d8fb5b93d4af21d66a2948710284366";
const form = document.querySelector("form")
const row = document.getElementsByClassName("row")[0];
const input = form.querySelector('input')
console.log(row)
console.log(form)
console.log(input)
const msg = document.querySelector(".msg");
let user_cities = []
///////////////////////////


for (var i = 0; i < data['user_cities'].length; i++) {

    console.log(`x:${data['user_cities'][i]} `);


    //here goes AJAX
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${data['user_cities'][i]}&appid=${apiKey}&units=metric`;
    fetch(url)
        .then(response => {
            if (response.status == 404) {
                msg.innerHTML = "enter a valid city name";
                form.reset()
                input.focus()
                msg.style.display = "block"
                return;
            }
            else {
                return response.json();
            }
        }).then(data => {
            if (!data) {
                msg.innerHTML = "enter a valid city name";
                form.reset()
                input.focus()
                msg.style.display = "block"
                return;
            }

            const temp = Math.round(data['main']['temp'])
            const name = data['name']
            const country = data['sys']['country']
            const icon = data['weather'][0]['icon']
            const main = data['weather'][0]['main']

            let col_lg_4 = document.createElement('div')
            col_lg_4.classList.add("col-lg-4");
            let city = document.createElement("div");
            city.classList.add("city");
            let icon_url = `https://s3-us-west-2.amazonaws.com/s.cdpn.io/162656/${icon
                }.svg`;
            city.innerHTML = `<h2 data-name="${name},${country}">
<span>${name}</span>  
<sup>${country}</sup>  
</h2>
<div class="temp">
${temp}<sup>°C</sup>
</div>
<figure>
  <img src="${icon_url}">
  <figcaption>
     ${main}
  </figcaption>
</figure>
`
            col_lg_4.appendChild(city);

            row.appendChild(col_lg_4)

            // window.location.assign(`/weather?city=${name}`);



        })
}





//////////////////////////////////////
form.addEventListener("submit", createWeather);


function createWeather(e) {
    e.preventDefault();
    /// consoling out our user's city list

    ///////////////////////////////////////////////////
    let city_name = input.value;
    if (city_name.includes(',')) {
        if (city_name.split(",")[0].length < 2) {
            if (city_name.split(",")[1].length > 1) {
                city_name = city_name.split(',')[1];
            }
            else {
                form.reset();
                input.focus()
                msg.innerHTML = `enter valid city name`;
                msg.style.display = "block";
            }
        }
        else if (city_name.split(",")[0].length >= 2) {
            city_name = city_name.split(',')[0];
        }
        else {
            form.reset();
            input.focus()
            msg.innerHTML = `enter valid city name`;
            msg.style.display = "block";
        }
    }
    let cols = document.querySelectorAll(".col-lg-4")
    cols = Array.from(cols)
    let filtered_array = []
    if (cols.length > 0) {
        filtered_array = cols.filter(col => {
            let name_city = col.firstElementChild.firstElementChild.dataset.name.split(',')[0];
            let name_country = col.firstElementChild.firstElementChild.dataset.name.split(',')[1];
            let pattr1 = new RegExp(city_name.toLowerCase().trim(), 'i')
            if (name_city.toLowerCase().trim().search(pattr1) != -1) {
                return col;
            }


        })
        if (filtered_array.length > 0) {

            msg.innerHTML = `you already know forecast for ${city_name} `;
            msg.style.display = "block";
            form.reset()
            input.focus()
            return;

        }


    }


    'https://api.openweathermap.org/data/2.5/weather?=Osh&appid=4d8fb5b93d4af21d66a2948710284366&units=metric'


    //here goes AJAX
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city_name}&appid=${apiKey}&units=metric`;
    fetch(url)
        .then(response => {
            if (response.status == 404) {
                msg.innerHTML = "enter a valid city name";
                form.reset()
                input.focus()
                msg.style.display = "block"
                return;
            }
            else {
                return response.json();
            }
        }).then(data => {
            if (!data) {
                msg.innerHTML = "enter a valid city name";
                form.reset()
                input.focus()
                msg.style.display = "block"
                return;
            }

            temp = Math.round(data['main']['temp'])
            name = data['name']
            country = data['sys']['country']
            icon = data['weather'][0]['icon']
            main = data['weather'][0]['main']

            col_lg_4 = document.createElement('div')
            col_lg_4.classList.add("col-lg-4");
            city = document.createElement("div");
            city.classList.add("city");
            icon_url = `https://s3-us-west-2.amazonaws.com/s.cdpn.io/162656/${icon
                }.svg`;
            city.innerHTML = `<h2 data-name="${name},${country}">
<span>${name}</span>  
<sup>${country}</sup> 

</h2>
<div class="temp">
${temp}<sup>°C</sup>

</div>
<figure>
  <img src="${icon_url}">
  <figcaption>
     ${main}
  </figcaption>
</figure>



`
            col_lg_4.appendChild(city);

            row.appendChild(col_lg_4)

            // window.location.assign(`/weather?city=${name}`);



        })





}
fetch('https://raw.githubusercontent.com/country-regions/country-region-data/master/data.json').then(response => {
    return response.json();
}).then(data => {

    /////////////////////////////////autocoomplete goes here


    $("#search").keyup(function () {
        $('#result').html('')
        let val = $('#search').val();
        // console.log(val);
        let expression = new RegExp(val, 'i');

        $.each(data, function (key, val) {

            if (data[key]['countryName'].search(expression) != -1) {
                let li = `<li class="list-group-item"><span>${data[key]['countryName']}</span>|
    <span>${data[key]['countryShortCode']}</span></li>`


                document.getElementById("result").appendChild(li);





                $("li").click(function () {
                    let name = data[key]['countryName'];
                    $('#search').val(name)
                    $("#result").html("");
                    data[key]['regions'].forEach((city) => {
                        let li = document.createElement("li");
                        li.innerHTML = `<li class="list-group-item"><span>${city.name}</span>|
      <span>${city.shortCode}</span></li>`
                        document.getElementById("result").appendChild(li);
                        li.addEventListener("click", function (e) {
                            $("#search").val(li.innerText.split("|")[0]);
                            $("#result").html("");
                        })



                    })

                })

            }
            else {

                $.each(data[key]['regions'], function (subkey, subval) {
                    if (data[key]['regions'][subkey].name.search(expression) != -1) {
                        const li = document.createElement("li");
                        li.innerHTML = `<li class="list-group-item"><span>${data[key]['regions'][subkey].name}</span>|
        <span>${data[key]['regions'][subkey].shortCode}</span></li>`


                        document.getElementById("result").appendChild(li);
                        li.addEventListener("click", function (e) {
                            $("#search").val(li.innerText.split("|")[0]);
                            $("#result").html("");
                        })


                    }
                })

            }





        })

    })


})