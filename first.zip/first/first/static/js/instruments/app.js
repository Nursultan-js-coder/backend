let loader;
let container;
let search_button;
let search_input;
let dict_carts;
let file_url=`http://clients1.google.com/complete/search?hl=en&output=toolbar&q=bish`;
function getElements(){
loader=document.querySelector(".wrapper")
container=document.querySelector(".container")
search_button=document.querySelector(".search-button");
search_input=document.querySelector(".search-input");
dict_carts=document.querySelector(".dict-carts");

}

getElements();

//end loading page
let data2;
let data3;



function click(){
    document.getElementById("link_id").addEventListener("click", function () {
    document.getElementById("linkAudio").play();
    })
}

function fetchWord(word){
    const container=document.querySelector(".container");
// container.innerHTML=`    <span class="cube"><span class="cube-inner"></span>
// `;

container.innerHTML=`<div class="cube"><div class="cube-inner">Hello hello</div>`
container.classList.add('wrapper');


fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`)
.then(response => {
    return response.json();
})
.then(data=>{
    if(container.classList.contains('wrapper')==true){
        container.classList.remove('wrapper');
    }
    container.innerHTML=`<header class="centerify"
    >
        <div class="header-top ">
            <h2 >Collins</h2>
    <form class="container-grid">
        <div class="result">
        <input type="text" class="search-input" >
        <ul class="autosuggest">
         
        </ul>
    </div>
        <button  class="search-button" ><i class="fas fa-search 3x"></i></button>
    </form>
        </div>
        <div class="progressBar">
            <div class="progressBarInner">
    
            </div>
        </div>
    <nav class="header-nav centerify">
        <ul class="header-nav-list">
            <li class="header-nav-item">English</li>
            <li class="header-nav-item">Arabic</li>
            <li class="header-nav-item">Turkish</li>
            <li class="header-nav-item">Kyrgyz</li>
            <li class="header-nav-item">Russian</li>
        </ul>
    </nav>
    
    </header>
    <main class="main"> 
    <div class="top-seperator"></div>
    <div class="main-content container-grid ">
        <div class="left-seperator"></div>
        <div class="box">
            <div class="dict-carts">
            <div class="navigators">
           <div>hello</div>
           <div>hello</div>
           <div>hello</div>
           <div>hello</div>
           <div>hello</div>
            </div>
        
    
        </div>
        <div class="sidebar">
            <div class="sidebar-box">
                <h3>Quick Word Chalange</h3>
              <div><p> Question: 1</p> <p>- Score: 0 / 5</p></div> 
               <p> whine or wine?</p>
                
               <p> Which version is correct?</p>
               <div><button>whine</button><button>wine</button></div>
            </div>
        </div>
        </div>
    </div>
    </main>
    <footer>
    footer
    </footer>
    
    
    
     <script src="jquery-3.5.1.min.js"></script>   
     <script src="app.js"></script>   
     <script src="processbarAndActiveNav.js"></script>   
     <script src="all.js"></script>  `


     getElements();
    data2=data;
    dict_carts.innerHTML=` <div class="navigators">
    <div>hello</div>
    <div>hello</div>
    <div>hello</div>
    <div>hello</div>
    <div>hello</div>
     </div>`;


     for(let i=0;i<data2[0]['meanings'].length;i++){

    for(let j=0;j<data2[0]['meanings'][i]['definitions'].length;j++){
let cart=document.createElement("div");
cart.classList.add('cart');
cart.innerHTML=`<div class="cart-header">
<h2 >Definition of '${data[0]['word']}'</h2>
<div >
   <div class="word-frequency">
       <span class="red"></span>
    <span class="red"></span>
    <span class="red"></span>
    <span class="red"></span>
    <span></span>
</div>
<div class="share"><span><i class="fas fa-share"></i></span>
<audio controls id="linkAudio">
  <source src="${data2[0]['phonetics'][0]['audio']} " type="audio/ogg">
  <source src="${data2[0]['phonetics'][0]['audio']} " type="audio/mpeg">
Your browser does not support the audio element.
</audio></div>
</div>

</div>
<div class="cart-definition">
<h4 class="definition">${data2[0]['meanings'][i]['definitions'][j]['definition']}</h4>
<span>1)${data2[0]['meanings'][i]['partOfSpeech']} :</span><p class="example"></p>
<ul class="synonyms">





    
</ul>
</div>`;
if(data2[0]['meanings'][i]['partOfSpeech']=="transitive verb"){

    data3=data2[0]['meanings'][i]['partOfSpeech'].trim().toLowerCase();
    data3=data3.split(" ");
    data3=data3.join("");
    cart.classList.add(data3);

    }
    else{
cart.classList.add(data2[0]['meanings'][i]['partOfSpeech'].toLowerCase());
    }

dict_carts.appendChild(cart);
console.log(dict_carts);

const ul =cart.querySelector(".synonyms");

if(data2[0]['meanings'][i]['definitions'][j]['synonyms']!=null){
    
for(let k=0;k<data2[0]['meanings'][i]['definitions'][j]['synonyms'].length;k++)
{
   
let li=document.createElement("li");
li.innerHTML=data2[0]['meanings'][i]['definitions'][j]['synonyms'][k];
ul.appendChild(li);
}
}

const example=cart.querySelector(".example");
if(data2[0]['meanings'][i]['definitions'][j]['example']!=null){
example.innerHTML=`${data2[0]['meanings'][i]['definitions'][j]['example']}`;

}

    }
}
// definition.innerHTML=data[0]['meanings']

})
.catch(err => {
	console.error(err);
});
}

// adding a event to search button

search_button.addEventListener("click",(e)=>{
    e.preventDefault();
    let word=search_input.value;
    word=word.trim().toLowerCase();
    fetchWord(word);
})
search_input.addEventListener('input',(e)=>{
    getElements();

    let search_input_value=search_input.value;
    let data5;
    file_url=`http://clients1.google.com/complete/search?hl=en&output=toolbar&q=${search_input_value}`;
fetch(file_url)
.then(response=>{
    return response.text();
})
.then(xmlString=>{
   let XmlNode = new DOMParser().parseFromString(xmlString, 'text/xml');
   let data_json=xmlToJson(XmlNode);
   let ul_autosuggest=document.querySelector(".autosuggest");
   ul_autosuggest.innerHTML="";
   for(let i=0;i<data_json['toplevel']['CompleteSuggestion'].length;i++){
       if(i==10){
           break;
       }
       let li_autosuggest=document.createElement("li");
       li_autosuggest.innerHTML=data_json['toplevel']['CompleteSuggestion'][i]['suggestion']['@attributes']['data'];
       console.log(data_json['toplevel']['CompleteSuggestion'][i]['suggestion']['@attributes']);
       li_autosuggest.addEventListener("click",e=>{
        search_input.value=li_autosuggest.innerHTML;
        fetchWord(search_input.value);

       })
       ul_autosuggest.appendChild(li_autosuggest);
    }
})

})

/**
 * Changes XML to JSON
 * Modified version from here: http://davidwalsh.name/convert-xml-json
 * @param {string} xml XML DOM tree
 */
function xmlToJson(xml) {
    // Create the return object
    var obj = {};
  
    if (xml.nodeType == 1) {
      // element
      // do attributes
      if (xml.attributes.length > 0) {
        obj["@attributes"] = {};
        for (var j = 0; j < xml.attributes.length; j++) {
          var attribute = xml.attributes.item(j);
          obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
        }
      }
    } else if (xml.nodeType == 3) {
      // text
      obj = xml.nodeValue;
    }
  
    // do children
    // If all text nodes inside, get concatenated text from them.
    var textNodes = [].slice.call(xml.childNodes).filter(function(node) {
      return node.nodeType === 3;
    });
    if (xml.hasChildNodes() && xml.childNodes.length === textNodes.length) {
      obj = [].slice.call(xml.childNodes).reduce(function(text, node) {
        return text + node.nodeValue;
      }, "");
    } else if (xml.hasChildNodes()) {
      for (var i = 0; i < xml.childNodes.length; i++) {
        var item = xml.childNodes.item(i);
        var nodeName = item.nodeName;
        if (typeof obj[nodeName] == "undefined") {
          obj[nodeName] = xmlToJson(item);
        } else {
          if (typeof obj[nodeName].push == "undefined") {
            var old = obj[nodeName];
            obj[nodeName] = [];
            obj[nodeName].push(old);
          }
          obj[nodeName].push(xmlToJson(item));
        }
      }
    }
    return obj;
  }
 
 



//   const response = await fetch('file_url');
//   const xmlString = await response.text();
//   var XmlNode = new DOMParser().parseFromString(xmlString, 'text/xml');
//   let data_json=xmlToJson(XmlNode);
//   console.log(data_json);


   /* 
  2. If you have an XML as string:
  
  var XmlNode = new DOMParser().parseFromString(yourXmlString, 'text/xml');
  xmlToJson(XmlNode);
  
  3. If you have the XML as a DOM Node:
  
  xmlToJson(YourXmlNode);
  */




