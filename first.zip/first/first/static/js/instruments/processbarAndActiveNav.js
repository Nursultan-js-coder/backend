const width=$(document).height();
const progressBarInner=document.querySelector(".progressBarInner");


window.addEventListener("scroll",(e)=>{
    let y=window.scrollY;
    progressBarInner.style.width=Math.round((y)/width*100)+"%";
   
   
  
})

