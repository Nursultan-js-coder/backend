
$("#search").keyup(function(){


  $('#result').html('')
let val=$('#search').val();

// console.log(val);
let expression=new RegExp(val,'i');

$.each(data['talebeler'],function(key,val){

 if(data['talebeler'][key]['name'].search(expression)!=-1 || data['talebeler'][key]['dershane'].search(expression)!=-1)
 {
  let li=document.createElement("li");
  let img=document.createElement("img");
  img.setAttribute('src',data['talebeler'][key]['img']);
  img.classList.add("img-circle")
  li.appendChild(img);
  let span=document.createElement("span");
  span.innerText=`${data['talebeler'][key]['name']}`;
  span.style.color="#555";
  span.style.fontSize="1rem";
  
  li.appendChild(span);
  let span2=document.createElement("span");

  span2.innerText=` | ${data['talebeler'][key]['dershane']}`
  span2.style.color="#888";
  span2.style.fontSize="0.7rem";
  li.appendChild(span2);

   li.classList.add("container-flex");
   li.classList.add("justify-content-between");
   li.classList.add("marginify");
  document.getElementById("result").appendChild(li);
  console.log(data['talebeler'][key]['name'])
  synchronize();
  // li.addEventListener("click",function(e){
  //   $("#result").html("");
  //   $("#search").val(li.innerText.split("|")[0]);
  // })
}

})
})

///////////////////////////////////////////////////////////////////////////////////////////
