from django.shortcuts import render
from .models import Article, Comment
from .serializers import *
from rest_framework import viewsets
from .forms import CommentForm, RespondForm, ArticleForm

# Create your views here.


class ArticleViewSet(viewsets.ModelViewSet):
    queryset = Article.objects.all()
    serializer_class = ArticleSerializer


class CommentViewSet(viewsets.ModelViewSet):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer


class RespondViewSet(viewsets.ModelViewSet):
    queryset = Respond.objects.all()
    serializer_class = RespondSerializer


def home(request):
    articles = Article.objects.all()
    print("title of the first article:  ", articles[0].title)
    message = "hi hello how are you"
    form = ArticleForm()
    context = {
        "articles": articles,
        'count': len(Comment.objects.all()),


    }

    return render(request, 'articles/home.html', context)


def article_detail(request, pk):
    article = Article.objects.get(id=pk)
    comments = Comment.objects.all().filter(article=article)
    commentForm = CommentForm()
    respondForm = RespondForm()

    if request.method == 'POST':
        commentForm = CommentForm(request.POST)
        if commentForm.is_save():
            comment = commentForm(commit=False)
            comment.article = article
            comment.save()
            comments = Comment.objects.all().filter(article=article)

            context = {
                'comments': comments,
                'article': article,
                'comments': comments,
                'commentForm': commentForm,
                'respondForm': respondForm

            }
            return render(request, "articles/article_detail.html", context)
    else:
        context = {
            'comments': comments,
            'article': article,
            'comments': comments,
            'commentForm': commentForm,
            'respondForm': respondForm

        }
    return render(request, "articles/article_detail.html", context)


def article_leave_comment(request, pk):
    pass


def comment_respond(request, pk):
    pass


def answers(request, pk):
    pass
