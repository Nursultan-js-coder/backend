from rest_framework import serializers
from articles.models import *


# ViewSets define the view behavior.


class ArticleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Article
        fields = '__all__'


class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = '__all__'


class RespondSerializer(serializers.ModelSerializer):
    class Meta:
        model = Respond
        fields = '__all__'
