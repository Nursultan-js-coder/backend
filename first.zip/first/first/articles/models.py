from django.db import models
from accounts.models import Person

# Create your models here.


class Article (models.Model):
    title=models.CharField(max_length=50)
    author=models.ManyToManyField(Person)
    content=models.TextField()
    date=models.DateTimeField( auto_now_add=True)
    def __str__(self):
        return self.title

    def snippet(self):
        return self.content[:50]+" ..."

class Comment(models.Model):
    content=models.TextField()
    author=models.ForeignKey(Person , on_delete=models.CASCADE)   
    date=models.DateField(auto_now_add=False)
    article=models.ForeignKey(Article,on_delete=models.CASCADE)
    def __str__(self):
        return self.author.user.username+"' comment" 

class Respond (models.Model):
    content=models.TextField()
    comment=models.ForeignKey(Comment ,on_delete=models.CASCADE)
    author=models.ForeignKey(Person,on_delete=models.CASCADE)
    date=models.DateTimeField( auto_now_add=False)
    def __str__(self):
      return self.author.user.username+"' reply to "+self.comment.author.user.username
      



   
    

