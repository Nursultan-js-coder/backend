# from articles.models import *
# from rest_framework import viewsets, permissions
# from .serializers import *


# class ArticleViewSet(viewsets.ModelViewSet):
#     permission_classes = [
#         permissions.IsAuthenticated,
#     ]
#     serializer_class = ArticleSerializer

#     def get_queryset(self):
#         return self.request.user.Articles.all()

#     def perform_create(self, serializer):
#         serializer.save(author=self.request.user)


# class CommentViewSet(viewsets.ModelViewSet):
#     permission_classes = [
#         permissions.IsAuthenticated,
#     ]
#     serializer_class = CommentSerializer

#     def get_queryset(self):
#         return self.request.user.Comments.all()

#     def perform_create(self, serializer):
#         serializer.save(author=self.request.user)


# class RespondViewSet(viewsets.ModelViewSet):
#     permission_classes = [
#         permissions.IsAuthenticated,
#     ]
#     serializer_class = RespondSerializer

#     def get_queryset(self):
#         return self.request.user.Responds.all()

#     def perform_create(self, serializer):
#         serializer.save(author=self.request.user)
