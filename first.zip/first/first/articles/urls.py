from django.urls import path, include
from .api import *
from . import views
from rest_framework import viewsets, routers, serializers
from django.contrib.auth.models import User


# Wire up our API using automatic URL routing.
# Additionally, we include login URLs for the browsable API.
app_name = 'articles'
router = routers.DefaultRouter()
router.register(r'responds', views.RespondViewSet)
router.register(r'comments', views.CommentViewSet)
router.register(r'articles', views.ArticleViewSet)
urlpatterns = [
    path('home/', views.home, name="home"),
    path('article_detail/<int:pk>', views.article_detail, name="article_detail"),
    path('comment_respond/<int:pk>', views.comment_respond, name="comment_respond"),
    path('answers/<int:pk>', views.answers, name="answers"),
    path('article_leave_comment/<int:pk>',
         views.article_leave_comment, name="article_leave_comment"),
    path('', include(router.urls)),
    path('api-auth/', include('rest_framework.urls', namespace='rest_framework'))
]
