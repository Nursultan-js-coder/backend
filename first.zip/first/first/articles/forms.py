from django import forms
from .models import Article, Comment, Respond


class ArticleForm(forms.ModelForm):
    class Meta:
        model = Article
        fields = ['title', 'content']


class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['content']


class RespondForm(forms.ModelForm):
    class Meta:
        model = Respond
        fields = ['content']
