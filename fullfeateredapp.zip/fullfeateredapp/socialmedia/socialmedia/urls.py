
from django.contrib import admin
from django.urls import path,include
from users import views as users_views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf.urls.static import static
from django.conf import settings
app_name="social_media"

urlpatterns = [
    path('admin/', admin.site.urls),
    path('blog/',include('blog.urls')),
    path('register/',users_views.register,name="register"),
    path('profile/',users_views.profile,name="profile"),
    path('login/',users_views.login_user,name="login"),
    path('logout/',users_views.logout_user,name="logout"),
]

urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
