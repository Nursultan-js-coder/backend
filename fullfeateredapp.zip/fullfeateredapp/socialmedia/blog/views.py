from django.shortcuts import render,redirect,get_object_or_404
from . models import Post
from . forms import PostForm
from django.contrib.auth.models import User
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView
)


def home(request):
    if request.method == "POST":
        title=request.POST['title']
        if title !='':
            posts=Post.objects.all().filter(title=request.POST['title'])
            if len(posts)>0:
                messages.success(request,f'result for :{title} ')  
                return render(request,"blog/home.html",{"posts":posts})
            else :
                messages.warning(request,f'result for :{title} not found !')  
                return redirect("blog:blog-home")
        else:
                messages.warning(request,f'field can not be empty')  
                return redirect("blog:blog-home")

    else:
      posts=Post.objects.all()
      context={'posts':posts}
      return render(request,"blog/home.html",context)

class PostListView(ListView):
    model = Post
    template_name = 'blog/home.html'  # <app>/<model>_<viewtype>.html
    context_object_name = 'posts'
    ordering = ['-date']
    paginate_by = 2
class PostDetailView(DetailView):
    model=Post
    template_name = 'blog/detail.html'  # <app>/<model>_<viewtype>.html
    context_object_name = 'post'

class PostCreateView(LoginRequiredMixin,CreateView):
    model=Post
    fields=['title','content',]
    template_name = 'blog/new-blog.html'  # <app>/<model>_<viewtype>.html
         
    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)


def about(request):
    return render(request,"blog/about.html")

def detail(request,id):
    post=Post.objects.get(id=id)
    if post!=None:
        return render(request,"blog/detail.html",{"post":post})
    else :
        return redirect("blog:blog-home")       
@login_required(login_url="blog:login")        
def new_blog(request): 
    if request.method=="POST":
        form=PostForm(request.POST)
        if form.is_valid():
           instance=form.save(commit=False)
           instance.author=request.user
           instance.save()
           return redirect("blog:blog-home")
    else:
        form=PostForm()
    context={
        "form":form
    }    
    return render(request,"blog/new-blog.html",context)            

def userposts(request,username):
    user=User.objects.get(username=username)
    if user != None :
        posts=Post.objects.all().filter(author=user)
        messages.success(request,f'{username} posts:')
        return render(request,"users/user-page.html",{'posts':posts})   

class UserPostListView(ListView):
    model = Post
    template_name = 'blog/user-page.html'  # <app>/<model>_<viewtype>.html
    context_object_name = 'posts'
    paginate_by=5

    def get_queryset(self):
        user = get_object_or_404(User, username=self.kwargs.get('username'))
        return Post.objects.filter(author=user).order_by('-date')

