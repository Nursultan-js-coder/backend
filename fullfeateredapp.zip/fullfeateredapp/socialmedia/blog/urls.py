from django.contrib import admin
from django.urls import path,include
from . import views
from . views import (
    PostListView,
    PostDetailView,
    PostCreateView,
    UserPostListView,

    )

app_name="blog"

urlpatterns = [
    path('',PostListView.as_view(),name="blog-home"),
    path('detail/<str:pk>/',PostDetailView.as_view(),name="detail"),
    path('new/',PostCreateView.as_view(),name="new-blog"),
    path('search/',views.home,name="search"),
    path('user/<str:username>',UserPostListView.as_view(),name="userposts"),
]
