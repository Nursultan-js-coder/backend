from django.db import models

from clients.models import Customer

# Create your models here.


class Item(models.Model):
    name = models.CharField(max_length=50)
    price = models.FloatField()
    discount_price = models.FloatField(null=True, blank=True)
    description = models.TextField()
    img = models.ImageField(
        upload_to='items', height_field=None, width_field=None, max_length=None, default='default.jpg')

    def __str__(self):
        return self.name


class OrderItem(models.Model):
    item = models.ForeignKey(Item,
                             on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)

    def total(self):
        return self.item.price * self.quantity

    def __str__(self):
        return self.item.name+"-orderItem"


class Order(models.Model):
    item = models.ForeignKey(
        OrderItem,  on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now_add=True)
    customer = models.ForeignKey(
        Customer,  on_delete=models.CASCADE)

    def __str__(self):
        return self.customer.user.username+"' order at "+self.date
