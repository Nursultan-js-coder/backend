from django.db import models
from django.conf import settings

# Create your models here


class Company(models.Model):
    name = models.CharField(max_length=50)
    location = models.CharField(max_length=50)


class Customer(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,
                             on_delete=models.CASCADE)
    company = models.ForeignKey(
        Company, null=True, blank=True, on_delete=models.CASCADE)
