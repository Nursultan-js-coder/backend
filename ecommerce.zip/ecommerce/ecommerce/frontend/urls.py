from django.urls import path, include
from . import views
from rest_framework import viewsets, routers, serializers


router = routers.DefaultRouter()
router.register(r'items', views.ItemViewset)
router.register(r'orderItems', views.OrderItemViewset)
router.register(r'orders', views.OrderViewset)

urlpatterns = [
    path("", views.homepage, name="homepage"),
    path('api/', include(router.urls)),
    path('api-auth/', include('rest_framework.urls', namespace='rest_framework'))
]
