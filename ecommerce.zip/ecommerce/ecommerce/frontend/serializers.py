from rest_framework import serializers
from products.models import *


class ItemSerializer(serializers.ModelSerializer):
    class Meta:
        fields = '__all__'
        model = Item


class OrderItemSerializer(serializers.ModelSerializer):
    class Meta:
        fields = '__all__'
        model = OrderItem


class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        fields = '__all__'
        model = Order
