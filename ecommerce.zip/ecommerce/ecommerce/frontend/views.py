from django.shortcuts import render
from rest_framework import viewsets
from products.models import Item, OrderItem, Order
from .serializers import *


def homepage(request):
    items = Item.objects.all()
    context = {
        'items': items
    }
    print('itemszvzdfvbzdfbkdjfbzdfbzdfbzdfzdfzdf::::::::', items)
    return render(request, 'frontend/home.html', context)


class ItemViewset(viewsets.ModelViewSet):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer


class OrderItemViewset(viewsets.ModelViewSet):
    queryset = OrderItem.objects.all()
    serializer_class = OrderItemSerializer


class OrderViewset(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
